@echo off
call "%~dp0local-admin\start-admin.bat"
