$ErrorActionPreference='Stop'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$repo=Join-Path $root 'repo'
$site=Join-Path $root 'public-site'
Write-Host ''
Write-Host '========================================' -ForegroundColor DarkGray
Write-Host ' C2V3ZA Tools - GitHub Pages setup' -ForegroundColor Red
Write-Host '========================================' -ForegroundColor DarkGray
Write-Host ''
if(-not (Get-Command git -ErrorAction SilentlyContinue)){throw 'Git ist nicht installiert. Installiere Git for Windows und starte die Datei erneut.'}
if(-not(Test-Path(Join-Path $repo '.git'))){
  if(Test-Path $repo){throw "Der Ordner '$repo' existiert, ist aber kein Git-Repository."}
  Write-Host 'Klone https://github.com/C2V3ZA/tools.git ...' -ForegroundColor Cyan
  git clone 'https://github.com/C2V3ZA/tools.git' $repo
}else{Write-Host 'Vorhandenes lokales Repo gefunden. Bestehende Tool-Daten bleiben erhalten.' -ForegroundColor Yellow}
Write-Host 'Installiere Public Site...' -ForegroundColor Cyan
$copyFiles=@('index.html','app.js','styles.css','config.js','favicon.svg','.nojekyll','.gitignore','.gitattributes')
foreach($name in $copyFiles){Copy-Item -LiteralPath (Join-Path $site $name) -Destination (Join-Path $repo $name) -Force}
$wfDest=Join-Path $repo '.github\workflows'
New-Item -ItemType Directory -Path $wfDest -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $site '.github\workflows\pages.yml') -Destination (Join-Path $wfDest 'pages.yml') -Force
New-Item -ItemType Directory -Path (Join-Path $repo 'data') -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $repo 'downloads') -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $repo 'assets\screenshots') -Force | Out-Null
$toolsJson=Join-Path $repo 'data\tools.json'
if(-not(Test-Path $toolsJson)){Set-Content -Path $toolsJson -Value "{`n  \"tools\": []`n}" -Encoding UTF8}
Write-Host 'Entferne alte server-only Dateien...' -ForegroundColor Cyan
foreach($target in @('server.js','package.json','package-lock.json','scripts')){ $p=Join-Path $repo $target; if(Test-Path $p){Remove-Item -LiteralPath $p -Recurse -Force} }
Write-Host ''
Write-Host 'Fertig. Nichts an deinen Tool-Downloads oder Screenshots wurde gelöscht.' -ForegroundColor Green
Write-Host "Repo: $repo"
Write-Host ''
Write-Host 'Danach:' -ForegroundColor White
Write-Host '  git add -A'
Write-Host '  git commit -m "build: C2V3ZA Tools manager"'
Write-Host '  git push origin main'
Write-Host ''
Write-Host 'Local Admin: C2V3ZA-Tools\local-admin\start-admin.bat' -ForegroundColor Yellow
