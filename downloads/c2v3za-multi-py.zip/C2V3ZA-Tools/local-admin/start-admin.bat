@echo off
setlocal
cd /d "%~dp0"
if not exist node_modules\ (
  echo Installing local admin dependencies...
  call npm install || exit /b 1
)
start "C2V3ZA Tools Local Admin" cmd /k "npm start"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:8787/"
