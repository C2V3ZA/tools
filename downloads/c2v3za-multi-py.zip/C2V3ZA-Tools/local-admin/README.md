# C2V3ZA Tools — Local Admin

This folder is private. Do **not** upload it to GitHub Pages.

## Start

1. Install Node.js 20+.
2. Make sure your local Git repository exists at `../repo` and points to `https://github.com/C2V3ZA/tools.git`.
3. Double-click `start-admin.bat`.
4. Open `http://127.0.0.1:8787/`.
5. Password: `MeineElendigeEier10.`

## Management

The admin can create, edit, hide/show, delete and reorder tools.

Editing supports:

- German + English name/description
- category, version and tags
- optional ZIP replacement
- keep/remove existing screenshots
- add new screenshots
- publish/hidden state

Every change writes only the required repository files, creates a Git commit and pushes `main`.

The admin binds to `127.0.0.1` only. It uses an HttpOnly, SameSite cookie, CSRF protection, rate-limited login, strict security headers and file-signature checks. Tool ZIP files are never extracted or executed.
