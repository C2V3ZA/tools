import fs from "node:fs/promises";
import fsSync from "node:fs";
import path from "node:path";
import http from "node:http";
import crypto from "node:crypto";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import dotenv from "dotenv";
import Busboy from "busboy";

dotenv.config({ path: path.join(process.cwd(), ".env") });
const execFileAsync = promisify(execFile);
const ROOT = process.cwd();
const PUBLIC_DIR = path.join(ROOT, "public");
const PORT = Number(process.env.PORT || 8787);
const REPO_PATH = path.resolve(ROOT, process.env.REPO_PATH || "../repo");
const OWNER = String(process.env.REPO_OWNER || "C2V3ZA");
const REPO = String(process.env.REPO_NAME || "tools");
const BRANCH = String(process.env.REPO_BRANCH || "main");
const MAX_ZIP = Number(process.env.MAX_TOOL_ZIP_MB || 50) * 1024 * 1024;
const MAX_SHOT = Number(process.env.MAX_SCREENSHOT_MB || 5) * 1024 * 1024;
const MAX_SHOTS = Math.min(Number(process.env.MAX_SCREENSHOTS || 4), 4);
const ADMIN_HASH = String(process.env.ADMIN_PASSWORD_HASH || "");
const SESSION_SECRET = String(process.env.SESSION_SECRET || "");
const sessions = new Map();
const loginAttempts = new Map();

if (!ADMIN_HASH || !SESSION_SECRET) {
  console.error("Missing ADMIN_PASSWORD_HASH or SESSION_SECRET in .env");
  process.exit(1);
}

function parseCookies(header = "") {
  const out = {};
  for (const part of header.split(/;\s*/)) {
    if (!part) continue;
    const i = part.indexOf("=");
    const k = i < 0 ? part : part.slice(0, i);
    const v = i < 0 ? "" : part.slice(i + 1);
    out[k] = decodeURIComponent(v);
  }
  return out;
}
function token(bytes = 32) { return crypto.randomBytes(bytes).toString("base64url"); }
function sameBytes(a, b) {
  const aa = Buffer.isBuffer(a) ? a : Buffer.from(String(a));
  const bb = Buffer.isBuffer(b) ? b : Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function sessionFrom(req) {
  const id = parseCookies(req.headers.cookie || "").c2v3za_admin;
  return id ? sessions.get(id) || null : null;
}
function auth(req) { const s = sessionFrom(req); if (!s) return null; s.last = Date.now(); return s; }
function csrfOk(req, s) { return Boolean(s && sameBytes(String(req.headers["x-csrf-token"] || ""), s.csrf)); }
function issueSession(res) {
  const id = token(32), csrf = token(24);
  sessions.set(id, { csrf, created: Date.now(), last: Date.now() });
  res.setHeader("Set-Cookie", `c2v3za_admin=${encodeURIComponent(id)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800`);
  return csrf;
}
function clearSession(res, req) {
  const id = parseCookies(req.headers.cookie || "").c2v3za_admin;
  if (id) sessions.delete(id);
  res.setHeader("Set-Cookie", "c2v3za_admin=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0");
}
function setSecurity(res) {
  res.setHeader("Content-Security-Policy", "default-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'; form-action 'self'; script-src 'self'; style-src 'self'; img-src 'self' blob: data:; connect-src 'self'; font-src 'self'");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
}
function json(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(body);
}
async function readJson(req, max = 64 * 1024) {
  let raw = "";
  for await (const chunk of req) { raw += chunk; if (raw.length > max) throw new Error("Request too large"); }
  return JSON.parse(raw || "{}");
}
function cleanText(v, max = 500) { return String(v ?? "").trim().replace(/\s+/g, " ").slice(0, max); }
function validSlug(v) { return /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(v) && v.length <= 64; }
function safeRepoPath(p, prefix) {
  const s = String(p || "");
  return s.startsWith(prefix) && !s.includes("\\") && !s.includes("..") && !s.startsWith("/") ? s : null;
}
function hasSig(buf, kind) {
  if (kind === "zip") return buf.length >= 4 && buf[0] === 0x50 && buf[1] === 0x4b && [0x03, 0x05, 0x07].includes(buf[2]);
  if (kind === "png") return buf.length >= 8 && buf.subarray(0, 8).equals(Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a]));
  if (kind === "jpeg") return buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
  if (kind === "webp") return buf.length >= 12 && buf.subarray(0,4).toString() === "RIFF" && buf.subarray(8,12).toString() === "WEBP";
  return false;
}
function imageExt(buf) { if (hasSig(buf,"png")) return ".png"; if (hasSig(buf,"jpeg")) return ".jpg"; if (hasSig(buf,"webp")) return ".webp"; return null; }
async function collectMultipart(req) {
  return await new Promise((resolve, reject) => {
    const bb = Busboy({ headers: req.headers, limits: { fileSize: MAX_ZIP, files: 1 + MAX_SHOTS, parts: 40, fields: 24 } });
    const fields = {}; const files = []; let failed = false;
    bb.on("field", (n, v) => { fields[n] = v; });
    bb.on("file", (name, stream, info) => {
      const limit = name === "screenshots" ? MAX_SHOT : MAX_ZIP; const chunks=[]; let total=0;
      stream.on("data", chunk => { total += chunk.length; if(total > limit && !failed){ failed=true; stream.resume(); reject(new Error(`${name} exceeds its size limit`)); return; } if(!failed) chunks.push(chunk); });
      stream.on("end", ()=>{ if(!failed) files.push({name,original:info.filename,mime:info.mimeType,size:total,buffer:Buffer.concat(chunks)}); });
    });
    bb.on("error", e=>{ if(!failed){failed=true;reject(e);} });
    bb.on("close", ()=>{ if(!failed) resolve({fields,files}); }); req.pipe(bb);
  });
}
async function readIndex() {
  try { const p = path.join(REPO_PATH,"data","tools.json"); const d=JSON.parse(await fs.readFile(p,"utf8")); const list=Array.isArray(d)?d:d?.tools; return Array.isArray(list)?list:[]; }
  catch { return []; }
}
function normalizeTool(t) {
  if(!t || typeof t!=="object" || !validSlug(String(t.slug||""))) return null;
  const download=safeRepoPath(t.download,"downloads/");
  if(!download) return null;
  const screenshots=Array.isArray(t.screenshots)?t.screenshots.map(x=>safeRepoPath(x,"assets/screenshots/")).filter(Boolean).slice(0,MAX_SHOTS):[];
  return { ...t, slug:String(t.slug), category:cleanText(t.category,48), version:cleanText(t.version||"1.0.0",24), tags:Array.isArray(t.tags)?t.tags.map(x=>cleanText(x,32)).filter(Boolean).slice(0,12):[], screenshots, download, published:t.published!==false };
}
async function writeIndex(list) {
  const file = path.join(REPO_PATH,"data","tools.json"); await fs.mkdir(path.dirname(file),{recursive:true});
  const tmp=`${file}.tmp-${process.pid}-${Date.now()}`; await fs.writeFile(tmp,JSON.stringify({tools:list},null,2)+"\n","utf8"); await fs.rename(tmp,file);
}
async function git(args){return execFileAsync("git",args,{cwd:REPO_PATH,windowsHide:true,maxBuffer:8*1024*1024});}
async function ensureGit(){try{await git(["rev-parse","--is-inside-work-tree"]);}catch{throw new Error("Der lokale Ordner ist kein Git-Repository.");}}
async function commitPush(paths,message){
  if(!paths.length) throw new Error("Keine Änderungen zu speichern.");
  await git(["add","--",...paths]);
  const status=(await git(["status","--porcelain"])).stdout.trim();
  if(!status) return;
  try{await git(["commit","-m",message]);}catch(e){throw new Error(`Git Commit fehlgeschlagen: ${e.stderr?.trim()||e.message}`)}
  try{await git(["push","origin",BRANCH]);}catch(e){throw new Error(`Git Push fehlgeschlagen. Lokaler Commit bleibt erhalten: ${e.stderr?.trim()||e.message}`)}
}
function recordFiles(t){return [t.download,...(Array.isArray(t.screenshots)?t.screenshots:[])];}
function safeFileInRepo(rel, rootPrefix){
  const ok=safeRepoPath(rel,rootPrefix); if(!ok)throw new Error("Ungültiger Dateipfad");
  const abs=path.resolve(REPO_PATH,rel); const root=path.resolve(REPO_PATH,rootPrefix); if(abs!==root&&!abs.startsWith(root+path.sep))throw new Error("Ungültiger Dateipfad"); return abs;
}
async function writeToolFiles(slug, zip, shots, oldShots=[]) {
  const downloads=path.join(REPO_PATH,"downloads"), dir=path.join(REPO_PATH,"assets","screenshots");
  await fs.mkdir(downloads,{recursive:true});await fs.mkdir(dir,{recursive:true});
  const written=[];
  if(zip){ const dest=safeFileInRepo(`downloads/${slug}.zip`,"downloads/"); await fs.writeFile(dest,zip.buffer); written.push(`downloads/${slug}.zip`); }
  for(let i=0;i<oldShots.length;i++){
    const old=oldShots[i]; try{const data=await fs.readFile(safeFileInRepo(old,"assets/screenshots/")); shots._kept.push({buffer:data});}catch{ /* missing files are simply skipped */ }
  }
  for(const p of oldShots) { try{await fs.rm(safeFileInRepo(p,"assets/screenshots/"),{force:true});}catch{} }
  const all=[...shots._kept,...shots.newFiles];
  if(all.length>MAX_SHOTS)throw new Error(`Maximal ${MAX_SHOTS} Screenshots`);
  const newPaths=[];
  for(let i=0;i<all.length;i++){
    const buf=all[i].buffer; const ext=imageExt(buf); if(!ext)throw new Error("Ungültiges Screenshot-Format");
    const rel=`assets/screenshots/${slug}-${String(i+1).padStart(2,"0")}${ext}`; await fs.writeFile(safeFileInRepo(rel,"assets/screenshots/"),buf); written.push(rel); newPaths.push(rel);
  }
  return newPaths;
}
async function validateMeta(fields){
  const slug=cleanText(fields.slug,64); if(!validSlug(slug))throw new Error("Ungültiger Slug");
  const name={de:cleanText(fields.name_de,80),en:cleanText(fields.name_en,80)}; const description={de:cleanText(fields.description_de,500),en:cleanText(fields.description_en,500)};
  if(!fields.category||!name.de||!name.en||!description.de||!description.en)throw new Error("Bitte alle Pflichtfelder ausfüllen");
  const tags=cleanText(fields.tags,180).split(",").map(x=>cleanText(x,32)).filter(Boolean).slice(0,12);
  return {slug,category:cleanText(fields.category,48),version:cleanText(fields.version||"1.0.0",24),name,description,tags,published:String(fields.published)!=="false"};
}
async function createTool(fields,files){
  await ensureGit(); const meta=await validateMeta(fields); const list=await readIndex(); if(list.some(t=>t?.slug===meta.slug))throw new Error("Dieser Slug existiert bereits");
  const zip=files.find(f=>f.name==="toolZip"); const screenshots=files.filter(f=>f.name==="screenshots");
  if(!zip||!hasSig(zip.buffer,"zip"))throw new Error("Die Tool-Datei muss ein echtes ZIP sein.");
  if(screenshots.length>MAX_SHOTS)throw new Error(`Maximal ${MAX_SHOTS} Screenshots`); for(const s of screenshots)if(!imageExt(s.buffer))throw new Error("Ein Screenshot ist kein PNG/JPG/WebP.");
  screenshots._kept=[];screenshots.newFiles=screenshots;
  const shotPaths=await writeToolFiles(meta.slug,zip,screenshots,[]);
  const now=new Date().toISOString(); const record={...meta,screenshots:shotPaths,download:`downloads/${meta.slug}.zip`,publishedAt:now,updatedAt:now};
  await writeIndex([record,...list]); await commitPush([record.download,"data/tools.json",...shotPaths],`feat: add tool ${meta.slug}`); return record;
}
async function updateTool(oldSlug,fields,files){
  await ensureGit(); const list=await readIndex(); const index=list.findIndex(t=>t?.slug===oldSlug); if(index<0)throw new Error("Tool nicht gefunden"); const old=normalizeTool(list[index]); if(!old)throw new Error("Das bestehende Tool ist beschädigt"); const meta=await validateMeta({...fields,slug:oldSlug});
  const zip=files.find(f=>f.name==="toolZip"); if(zip&&!hasSig(zip.buffer,"zip"))throw new Error("Die neue Tool-Datei muss ein echtes ZIP sein.");
  const newShots=files.filter(f=>f.name==="screenshots"); if(newShots.length>MAX_SHOTS)throw new Error(`Maximal ${MAX_SHOTS} neue Screenshots`); for(const s of newShots)if(!imageExt(s.buffer))throw new Error("Ein neuer Screenshot ist kein PNG/JPG/WebP.");
  const keepRaw=String(fields.keep_screenshots||"[]"); let keep=[]; try{keep=JSON.parse(keepRaw);}catch{throw new Error("Screenshot-Auswahl ist ungültig");} if(!Array.isArray(keep))throw new Error("Screenshot-Auswahl ist ungültig");
  const keepSafe=keep.filter(p=>Array.isArray(old.screenshots)&&old.screenshots.includes(p)); const oldKept=keepSafe;
  const wrapper={_kept:[],newFiles:newShots}; const shotPaths=await writeToolFiles(oldSlug,zip,wrapper,oldKept);
  const record={...meta,screenshots:shotPaths,download:old.download,publishedAt:old.publishedAt||new Date().toISOString(),updatedAt:new Date().toISOString()};
  list[index]=record; await writeIndex(list);
  const paths=new Set(["data/tools.json",record.download,...shotPaths,...old.screenshots]);
  await commitPush([...paths],`chore: update tool ${oldSlug}`); return record;
}
async function togglePublished(slug,published){await ensureGit();const list=await readIndex();const i=list.findIndex(t=>t?.slug===slug);if(i<0)throw new Error("Tool nicht gefunden");list[i]={...list[i],published:Boolean(published),updatedAt:new Date().toISOString()};await writeIndex(list);await commitPush(["data/tools.json"],`${published?"publish":"hide"}: ${slug}`);return list[i];}
async function deleteTool(slug){await ensureGit();const list=await readIndex();const i=list.findIndex(t=>t?.slug===slug);if(i<0)throw new Error("Tool nicht gefunden");const t=normalizeTool(list[i]);if(!t)throw new Error("Das Tool ist beschädigt");for(const rel of recordFiles(t)){const prefix=rel.startsWith("downloads/")?"downloads/":"assets/screenshots/";try{await fs.rm(safeFileInRepo(rel,prefix),{force:true});}catch{}}list.splice(i,1);await writeIndex(list);await commitPush(["data/tools.json",...recordFiles(t)],`chore: delete tool ${slug}`);return {slug};}
async function reorder(order){await ensureGit();if(!Array.isArray(order)||order.length>500)throw new Error("Ungültige Reihenfolge");const list=await readIndex();const map=new Map(list.map(t=>[t.slug,t]));const next=[];const seen=new Set();for(const slug of order){if(map.has(slug)&&!seen.has(slug)){next.push(map.get(slug));seen.add(slug);}}for(const t of list)if(!seen.has(t.slug))next.push(t);await writeIndex(next);await commitPush(["data/tools.json"],"chore: reorder tools");return next;}
async function status(){let gitAvailable=true,isRepo=false,remote="";try{await execFileAsync("git",["--version"],{windowsHide:true});}catch{gitAvailable=false}const exists=fsSync.existsSync(REPO_PATH);if(exists&&gitAvailable){try{await git(["rev-parse","--is-inside-work-tree"]);isRepo=true;remote=(await git(["config","--get","remote.origin.url"])).stdout.trim();}catch{}}return {repoExists:exists,repoName:path.basename(REPO_PATH),gitAvailable,gitRepo:isRepo,remote,owner:OWNER,repo:REPO,branch:BRANCH};}
async function serveStatic(req,res){const url=new URL(req.url,`http://${req.headers.host||"127.0.0.1"}`);let rel=decodeURIComponent(url.pathname);if(rel==="/"||rel==="/admin")rel="/index.html";const file=path.resolve(PUBLIC_DIR,"."+rel);if(!file.startsWith(PUBLIC_DIR+path.sep))return json(res,403,{error:"Forbidden"});try{const stat=await fs.stat(file);if(!stat.isFile())return json(res,404,{error:"Not found"});const ext=path.extname(file);const type={".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".css":"text/css; charset=utf-8"}[ext]||"application/octet-stream";res.writeHead(200,{"Content-Type":type,"Cache-Control":"no-store"});fsSync.createReadStream(file).pipe(res);}catch{json(res,404,{error:"Not found"});}}
async function serveMedia(req,res,slug,file){const s=auth(req);if(!s)return json(res,401,{error:"Authentication required"});const list=await readIndex();const t=list.find(x=>x?.slug===slug);if(!t)return json(res,404,{error:"Tool not found"});const allowed=(Array.isArray(t.screenshots)?t.screenshots:[]).map(x=>String(x).split("/").pop());if(!allowed.includes(file))return json(res,403,{error:"Forbidden"});const rel=`assets/screenshots/${file}`;const abs=safeFileInRepo(rel,"assets/screenshots/");try{const data=await fs.readFile(abs);const ext=path.extname(file).toLowerCase();const type={".png":"image/png",".jpg":"image/jpeg",".webp":"image/webp"}[ext]||"application/octet-stream";res.writeHead(200,{"Content-Type":type,"Cache-Control":"no-store","X-Content-Type-Options":"nosniff"});res.end(data);}catch{json(res,404,{error:"File not found"});}}
async function main(){
  if(process.argv.includes("--hash-password")){const password=await new Promise(resolve=>{process.stdout.write("Password: ");process.stdin.setEncoding("utf8");process.stdin.once("data",d=>resolve(d.trimEnd()));});const salt=crypto.randomBytes(16);const key=await new Promise((resolve,reject)=>crypto.scrypt(password,salt,64,{N:16384,r:8,p:1},(e,k)=>e?reject(e):resolve(k)));console.log(`scrypt$16384$8$1$${salt.toString("base64")}$${key.toString("base64")}`);return;}
  setInterval(()=>{const now=Date.now();for(const[k,v]of sessions)if(now-v.last>8*60*60*1000)sessions.delete(k);for(const[k,v]of loginAttempts)if(now-v.at>15*60*1000)loginAttempts.delete(k);},60000).unref();
  const server=http.createServer(async(req,res)=>{setSecurity(res);try{const url=new URL(req.url,`http://${req.headers.host||"127.0.0.1"}`);
    if(req.method==="POST"&&url.pathname==="/api/login"){const key=req.socket.remoteAddress||"local";const a=loginAttempts.get(key)||{count:0,at:Date.now()};if(a.count>=8&&Date.now()-a.at<600000)return json(res,429,{error:"Zu viele Versuche. Bitte später erneut versuchen."});const body=await readJson(req);const parts=ADMIN_HASH.split("$");if(parts.length!==6||parts[0]!=="scrypt")return json(res,500,{error:"Password configuration invalid"});const[,N,r,p,saltB64,hashB64]=parts;const expected=Buffer.from(hashB64,"base64");const derived=await new Promise((resolve,reject)=>crypto.scrypt(String(body.password||""),Buffer.from(saltB64,"base64"),expected.length,{N:Number(N),r:Number(r),p:Number(p)},(e,k)=>e?reject(e):resolve(k)));if(!sameBytes(derived,expected)){loginAttempts.set(key,{count:a.count+1,at:a.at});return json(res,401,{error:"Invalid password"});}loginAttempts.delete(key);return json(res,200,{ok:true,csrf:issueSession(res)});}
    if(req.method==="GET"&&url.pathname==="/api/session"){const s=auth(req);return json(res,200,s?{authenticated:true,csrf:s.csrf}:{authenticated:false});}
    if(req.method==="POST"&&url.pathname==="/api/logout"){const s=auth(req);if(!s||!csrfOk(req,s))return json(res,403,{error:"Forbidden"});clearSession(res,req);return json(res,200,{ok:true});}
    if(req.method==="GET"&&url.pathname==="/api/status"){const s=auth(req);if(!s)return json(res,401,{error:"Authentication required"});return json(res,200,await status());}
    if(req.method==="GET"&&url.pathname==="/api/tools"){const s=auth(req);if(!s)return json(res,401,{error:"Authentication required"});return json(res,200,{tools:await readIndex()});}
    if(req.method==="GET"&&url.pathname.startsWith("/api/media/")){const s=auth(req);if(!s)return json(res,401,{error:"Authentication required"});const parts=url.pathname.split("/");if(parts.length<5)return json(res,404,{error:"Not found"});return serveMedia(req,res,decodeURIComponent(parts[3]),decodeURIComponent(parts[4]));}
    if(req.method==="POST"&&url.pathname==="/api/tools/create"){const s=auth(req);if(!s||!csrfOk(req,s))return json(res,403,{error:"Forbidden"});const {fields,files}=await collectMultipart(req);const tool=await createTool(fields,files);return json(res,200,{ok:true,tool});}
    const match=url.pathname.match(/^\/api\/tools\/([^/]+)(?:\/(update|publish))?$/); if(match){const slug=decodeURIComponent(match[1]); if(req.method==="DELETE"){const s=auth(req);if(!s||!csrfOk(req,s))return json(res,403,{error:"Forbidden"});return json(res,200,{ok:true,...await deleteTool(slug)});} if(req.method==="POST"&&match[2]==="update"){const s=auth(req);if(!s||!csrfOk(req,s))return json(res,403,{error:"Forbidden"});const {fields,files}=await collectMultipart(req);return json(res,200,{ok:true,tool:await updateTool(slug,fields,files)});} if(req.method==="POST"&&match[2]==="publish"){const s=auth(req);if(!s||!csrfOk(req,s))return json(res,403,{error:"Forbidden"});const b=await readJson(req);return json(res,200,{ok:true,tool:await togglePublished(slug,b.published===true)});} }
    if(req.method==="POST"&&url.pathname==="/api/tools/reorder"){const s=auth(req);if(!s||!csrfOk(req,s))return json(res,403,{error:"Forbidden"});return json(res,200,{ok:true,tools:await reorder((await readJson(req)).order)});}
    if(url.pathname.startsWith("/api/"))return json(res,404,{error:"Not found"}); return serveStatic(req,res);
  }catch(e){return json(res,400,{error:String(e?.message||e)})}});
  server.listen(PORT,"127.0.0.1",()=>console.log(`C2V3ZA Tools local admin: http://127.0.0.1:${PORT}`));
}
main().catch(e=>{console.error(e);process.exit(1)});
