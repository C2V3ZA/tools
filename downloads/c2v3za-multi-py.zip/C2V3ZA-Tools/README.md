# C2V3ZA Tools — GitHub Pages + Local Manager

## Was jetzt enthalten ist

**Public Site** (`public-site/`) ist für `https://c2v3za.github.io/tools/`.

**Local Admin** (`local-admin/`) bleibt nur auf deinem PC und ist nicht Teil der öffentlichen Website.

## Tool-Verwaltung

Das lokale Admin kann:

- neues Tool anlegen
- Tool bearbeiten
- Name/Description DE + EN ändern
- Kategorie, Version und Tags ändern
- ZIP ersetzen
- vorhandene Screenshots behalten oder entfernen
- neue Screenshots hinzufügen
- Tool veröffentlichen/verstecken
- Tools nach oben/unten verschieben
- Tool komplett löschen
- Suche + Filter benutzen
- Status und Tool-Anzahl sehen

Jede Änderung wird mit Git in `C2V3ZA/tools` committed und nach `main` gepusht.

## Wichtig

Der Local Admin wird **nicht** nach GitHub Pages kopiert.

Das Admin-Passwort ist bereits als scrypt-Hash eingerichtet:

`MeineElendigeEier10.`

Der Klartext steht nicht auf der öffentlichen Website.

## Einrichtung

1. Git for Windows installieren.
2. Node.js 20+ installieren.
3. ZIP entpacken.
4. `setup-github.bat` starten. Das Skript klont `C2V3ZA/tools` und aktualisiert nur die Website-Dateien. Bestehende `data/tools.json`, Downloads und Screenshots bleiben erhalten.
5. Im angezeigten `repo`-Ordner:

```powershell
git add -A
git commit -m "build: C2V3ZA Tools manager"
git push origin main
```

6. GitHub Pages muss auf **GitHub Actions** stehen. Der Workflow liegt unter `.github/workflows/pages.yml`.
7. Local Admin starten:

```text
local-admin\start-admin.bat
```

8. Browser öffnen:

`http://127.0.0.1:8787/`

## Sicherheit

Der Admin bindet nur an `127.0.0.1`, verwendet HttpOnly + SameSite-Cookie, CSRF-Schutz, Login-Rate-Limit, strenge Security-Header und prüft echte Dateisignaturen. ZIPs werden nie entpackt oder ausgeführt.

Die öffentliche Seite rendert Tool-Daten nur per DOM/Text APIs und filtert Tool-Links auf die erwarteten Verzeichnisse.

## Dateien im GitHub-Repo

```text
index.html
styles.css
app.js
config.js
favicon.svg
.nojekyll
data/tools.json
downloads/*.zip
assets/screenshots/*
.github/workflows/pages.yml
```

## Git-Zeilenenden unter Windows

LF/CRLF-Warnungen von Git sind normalerweise keine Fehler. Sie ändern nichts an der Funktionsweise der Website.
