(() => {
  "use strict";
  const I18N = {
    en: {
      "admin.kicker":"PUBLISH","admin.title":"C2V3ZA Tools","admin.subtitle":"Add one tool, its screenshots and its metadata. The app commits the files and pushes them to your GitHub repository.","logout":"Log out",
      "status.repo":"Repository","status.path":"Local repo","status.branch":"Branch","status.git":"Git",
      "form.kicker":"NEW TOOL","form.title":"Publish a tool","form.slug":"Slug","form.slugHint":"lowercase letters, numbers and dashes","form.category":"Category","form.categoryHint":"Short category label","form.version":"Version","form.versionHint":"Displayed as v1.0.0","form.tags":"Tags","form.tagsHint":"Comma-separated","form.nameDe":"Name — Deutsch","form.nameEn":"Name — English","form.descDe":"Beschreibung — Deutsch","form.descEn":"Description — English","form.zip":"Tool ZIP","form.zipHint":"ZIP only · max 50 MB · stored as a download","form.shots":"Screenshots","form.shotHint":"PNG/JPG/WebP · up to 4 · max 5 MB each","form.publish":"Publish to GitHub",
      "msg.publishing":"Publishing and pushing…","msg.success":"Published successfully. GitHub Pages will redeploy automatically.","msg.login":"Signed in.","msg.repoMissing":"Local repository not found.","msg.gitMissing":"Git is not available on this machine.","msg.ready":"Ready","msg.failed":"Check failed","msg.badToken":"","msg.badFiles":"Choose one ZIP and no more than four screenshots.","msg.duplicate":"That slug already exists. Choose another slug.","msg.generic":"The publish failed. See the server message below."
    },
    de: {
      "admin.kicker":"VERÖFFENTLICHEN","admin.title":"C2V3ZA Tools","admin.subtitle":"Füge ein Tool, seine Screenshots und Metadaten hinzu. Die App committet die Dateien und pusht sie in dein GitHub-Repository.","logout":"Abmelden",
      "status.repo":"Repository","status.path":"Lokales Repo","status.branch":"Branch","status.git":"Git",
      "form.kicker":"NEUES TOOL","form.title":"Tool veröffentlichen","form.slug":"Slug","form.slugHint":"Kleinbuchstaben, Zahlen und Bindestriche","form.category":"Kategorie","form.categoryHint":"Kurze Kategorie","form.version":"Version","form.versionHint":"Wird als v1.0.0 angezeigt","form.tags":"Tags","form.tagsHint":"Durch Kommas getrennt","form.nameDe":"Name — Deutsch","form.nameEn":"Name — Englisch","form.descDe":"Beschreibung — Deutsch","form.descEn":"Description — English","form.zip":"Tool-ZIP","form.zipHint":"Nur ZIP · max. 50 MB · wird als Download gespeichert","form.shots":"Screenshots","form.shotHint":"PNG/JPG/WebP · bis zu 4 · max. 5 MB pro Datei","form.publish":"Zu GitHub veröffentlichen",
      "msg.publishing":"Wird veröffentlicht und gepusht…","msg.success":"Erfolgreich veröffentlicht. GitHub Pages wird automatisch neu gebaut.","msg.login":"Angemeldet.","msg.repoMissing":"Lokales Repository nicht gefunden.","msg.gitMissing":"Git ist auf diesem Rechner nicht verfügbar.","msg.ready":"Bereit","msg.failed":"Prüfung fehlgeschlagen","msg.badFiles":"Wähle eine ZIP und höchstens vier Screenshots.","msg.duplicate":"Dieser Slug existiert bereits. Verwende einen anderen Slug.","msg.generic":"Die Veröffentlichung ist fehlgeschlagen. Die Servermeldung steht unten."
    }
  };
  let lang = "en"; const state = { csrf:null };
  const $ = (id) => document.getElementById(id);
  const tr = (key) => I18N[lang]?.[key] ?? I18N.en[key] ?? key;
  function detect() { try { const saved=localStorage.getItem("c2v3za-admin-language"); if(saved==="de"||saved==="en") return saved; } catch{} return (navigator.language||"").toLowerCase().startsWith("de") ? "de" : "en"; }
  function applyLang(next){lang=next==="de"?"de":"en";try{localStorage.setItem("c2v3za-admin-language",lang)}catch{};document.documentElement.lang=lang;$('languageSelect').value=lang;document.querySelectorAll('[data-i18n]').forEach(el=>el.textContent=tr(el.dataset.i18n));}
  function showLogin(){ $('loginView').hidden=false; $('adminView').hidden=true; state.csrf=null; }
  function showAdmin(){ $('loginView').hidden=true; $('adminView').hidden=false; }
  async function api(url, options={}){const headers=new Headers(options.headers||{});if(state.csrf)headers.set('X-CSRF-Token',state.csrf);const res=await fetch(url,{...options,headers});const data=await res.json().catch(()=>({}));if(!res.ok)throw new Error(data.error||"Request failed");return data;}
  function message(text, kind){const box=$('toolMessage');box.textContent=text;box.className=`message ${kind||''}`.trim();box.hidden=!text;}
  function preview(files){const grid=$('previewGrid');grid.replaceChildren();for(const file of [...files].slice(0,4)){const wrap=document.createElement('div');wrap.className='preview';const img=document.createElement('img');img.alt=file.name;const url=URL.createObjectURL(file);img.src=url;img.addEventListener('load',()=>URL.revokeObjectURL(url),{once:true});wrap.appendChild(img);grid.appendChild(wrap);}}
  async function refreshStatus(){try{const d=await api('/api/status');$('repoPathStatus').textContent=d.repoExists?d.repoName:'Missing';$('gitStatus').textContent=d.gitAvailable&&d.gitRepo?tr('msg.ready'):d.gitAvailable?tr('msg.failed'):tr('msg.gitMissing');}catch{$('repoPathStatus').textContent=tr('msg.failed');$('gitStatus').textContent=tr('msg.failed');}}
  document.addEventListener('DOMContentLoaded',async()=>{
    applyLang(detect());
    $('languageSelect').addEventListener('change',e=>applyLang(e.target.value));
    $('screenshots').addEventListener('change',e=>{if(e.target.files.length>4){e.target.value='';message(tr('msg.badFiles'),'bad');return}preview(e.target.files);});
    $('logoutButton').addEventListener('click',async()=>{try{await api('/api/logout',{method:'POST'})}catch{}showLogin();});
    $('loginForm').addEventListener('submit',async e=>{e.preventDefault();$('loginError').hidden=true;try{const d=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:$('password').value})});const payload=await d.json().catch(()=>({}));if(!d.ok)throw new Error(payload.error||'Login failed');state.csrf=payload.csrf;$('password').value='';showAdmin();await refreshStatus();}catch(err){$('loginError').textContent=err.message;$('loginError').hidden=false;}});
    $('toolForm').addEventListener('submit',async e=>{e.preventDefault();const zip=$('toolZip').files[0];const shots=$('screenshots').files;if(!zip||shots.length>4){message(tr('msg.badFiles'),'bad');return}const button=$('publishButton');button.disabled=true;button.textContent=tr('msg.publishing');message('', '');try{const form=new FormData($('toolForm'));const d=await api('/api/publish',{method:'POST',body:form});message(`${tr('msg.success')} ${d.name||''}`,'ok');$('toolForm').reset();$('previewGrid').replaceChildren();await refreshStatus();}catch(err){message(err.message||tr('msg.generic'),'bad');}finally{button.disabled=false;button.textContent=tr('form.publish');}});
    try{const session=await api('/api/session');if(session.authenticated){state.csrf=session.csrf;showAdmin();await refreshStatus();}else showLogin();}catch{showLogin();}
  });
})();
