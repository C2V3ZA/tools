import fs from "node:fs/promises";
import fsSync from "node:fs";
import path from "node:path";
import http from "node:http";
import crypto from "node:crypto";
import { execFile, spawn } from "node:child_process";
import { promisify } from "node:util";
import dotenv from "dotenv";
import Busboy from "busboy";

dotenv.config({ path: path.join(process.cwd(), ".env") });
const execFileAsync = promisify(execFile);
const ROOT = process.cwd();
const PUBLIC_DIR = path.join(ROOT, "public");
const PORT = Number(process.env.PORT || 8787);
const REPO_PATH = path.resolve(ROOT, process.env.REPO_PATH || "../repo");
const OWNER = process.env.REPO_OWNER || "C2V3ZA";
const REPO = process.env.REPO_NAME || "tools";
const BRANCH = process.env.REPO_BRANCH || "main";
const MAX_ZIP = Number(process.env.MAX_TOOL_ZIP_MB || 50) * 1024 * 1024;
const MAX_SHOT = Number(process.env.MAX_SCREENSHOT_MB || 5) * 1024 * 1024;
const MAX_SHOTS = Number(process.env.MAX_SCREENSHOTS || 4);
const ADMIN_HASH = String(process.env.ADMIN_PASSWORD_HASH || "");
const SESSION_SECRET = String(process.env.SESSION_SECRET || "");
const sessions = new Map();
const loginAttempts = new Map();

if (!ADMIN_HASH || !SESSION_SECRET) { console.error("Missing ADMIN_PASSWORD_HASH or SESSION_SECRET in .env"); process.exit(1); }

function parseCookies(header="") { return Object.fromEntries(header.split(/;\s*/).filter(Boolean).map(part => { const i=part.indexOf("="); return i<0?[part,""]:[part.slice(0,i),decodeURIComponent(part.slice(i+1))]; })); }
function newToken(bytes=32){return crypto.randomBytes(bytes).toString("base64url");}
function timingEqual(a,b){const aa=Buffer.from(String(a));const bb=Buffer.from(String(b));return aa.length===bb.length && crypto.timingSafeEqual(aa,bb);}
function clientKey(req){return req.socket.remoteAddress || "local";}
function currentSession(req){const cookies=parseCookies(req.headers.cookie||"");const id=cookies.c2v3za_admin;return id ? sessions.get(id) || null : null;}
function issueSession(res){const id=newToken(32), csrf=newToken(24);sessions.set(id,{csrf,created:Date.now(),last:Date.now()});res.setHeader("Set-Cookie",`c2v3za_admin=${encodeURIComponent(id)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800`);return csrf;}
function clearSession(res,req){const cookies=parseCookies(req.headers.cookie||"");if(cookies.c2v3za_admin)sessions.delete(cookies.c2v3za_admin);res.setHeader("Set-Cookie","c2v3za_admin=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0");}
function requireAuth(req){const s=currentSession(req);if(!s)return null;s.last=Date.now();return s;}
function requireCsrf(req,s){return s && String(req.headers["x-csrf-token"]||"")===s.csrf;}
function setSecurity(res){res.setHeader("Content-Security-Policy","default-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'; form-action 'self'; script-src 'self'; style-src 'self'; img-src 'self' blob: data:; connect-src 'self'");res.setHeader("X-Content-Type-Options","nosniff");res.setHeader("X-Frame-Options","DENY");res.setHeader("Referrer-Policy","no-referrer");res.setHeader("Permissions-Policy","camera=(), microphone=(), geolocation=()");}
function json(res,status,payload){const body=JSON.stringify(payload);res.writeHead(status,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});res.end(body);}
async function readJson(req){let raw="";for await(const chunk of req){raw+=chunk;if(raw.length>64*1024)throw new Error("Request too large");}return JSON.parse(raw||"{}");}
function safeSlug(slug){return /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug) && slug.length<=64;}
function safeText(value,max=500){return String(value??"").trim().replace(/\s+/g," ").slice(0,max);}
function hasSig(buf,kind){if(kind==="zip")return buf.length>=4 && buf[0]===0x50 && buf[1]===0x4b && [0x03,0x05,0x07].includes(buf[2]);if(kind==="png")return buf.length>=8&&buf.subarray(0,8).equals(Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a]));if(kind==="jpeg")return buf.length>=3&&buf[0]===0xff&&buf[1]===0xd8&&buf[2]===0xff;if(kind==="webp")return buf.length>=12&&buf.subarray(0,4).toString()==="RIFF"&&buf.subarray(8,12).toString()==="WEBP";return false;}
function extForImage(buf){if(hasSig(buf,"png"))return ".png";if(hasSig(buf,"jpeg"))return ".jpg";if(hasSig(buf,"webp"))return ".webp";return null;}
async function collectMultipart(req){return await new Promise((resolve,reject)=>{const bb=Busboy({headers:req.headers,limits:{fileSize:MAX_ZIP,files:1+MAX_SHOTS,parts:30,fields:20}});const fields={};const files=[];let errored=false;bb.on("field",(name,val)=>{fields[name]=val});bb.on("file",(name,stream,info)=>{const chunks=[];let total=0;const limit=name==="screenshots"?MAX_SHOT:MAX_ZIP;stream.on("data",chunk=>{total+=chunk.length;if(total>limit&&!errored){errored=true;stream.resume();reject(new Error(`${name} exceeds its size limit`));return}if(!errored)chunks.push(chunk)});stream.on("end",()=>{if(!errored)files.push({name,original:info.filename,mime:info.mimeType,size:total,buffer:Buffer.concat(chunks)})});});bb.on("error",err=>{if(!errored){errored=true;reject(err)}});bb.on("close",()=>{if(!errored)resolve({fields,files})});req.pipe(bb);});}
async function readIndex(repoDir){try{const text=await fs.readFile(path.join(repoDir,"data","tools.json"),"utf8");const data=JSON.parse(text);return Array.isArray(data)?data:(Array.isArray(data.tools)?data.tools:[]);}catch{return [];}}
async function writeAtomic(file,content){const tmp=`${file}.tmp-${process.pid}-${Date.now()}`;await fs.writeFile(tmp,content,{encoding:"utf8"});await fs.rename(tmp,file);}
async function git(args){return await execFileAsync("git",args,{cwd:REPO_PATH,windowsHide:true,maxBuffer:4*1024*1024});}
async function gitAvailable(){try{await execFileAsync("git",["--version"],{windowsHide:true});return true;}catch{return false;}}
async function status(){const exists=fsSync.existsSync(REPO_PATH);let isGit=false;let remote="";if(exists){try{await git(["rev-parse","--is-inside-work-tree"]);isGit=true;remote=(await git(["config","--get","remote.origin.url"])).stdout.trim();}catch{}}return {repoExists:exists,repoName:path.basename(REPO_PATH),gitAvailable:await gitAvailable(),gitRepo:isGit,remote};}
async function publish(fields,files){const slug=safeText(fields.slug,64);if(!safeSlug(slug))throw new Error("Invalid slug");const category=safeText(fields.category,48);const version=safeText(fields.version||"1.0.0",24);const nameDe=safeText(fields.name_de,80), nameEn=safeText(fields.name_en,80);const descDe=safeText(fields.description_de,500), descEn=safeText(fields.description_en,500);if(!category||!nameDe||!nameEn||!descDe||!descEn)throw new Error("Fill in all required fields");const zip=files.find(f=>f.name==="toolZip");const shots=files.filter(f=>f.name==="screenshots");if(!zip||!hasSig(zip.buffer,"zip"))throw new Error("The tool file must be a real ZIP archive");if(shots.length>MAX_SHOTS)throw new Error(`Maximum ${MAX_SHOTS} screenshots`);for(const s of shots)if(!extForImage(s.buffer))throw new Error("A screenshot is not a supported PNG/JPG/WebP image");if(!fsSync.existsSync(REPO_PATH))throw new Error(`Local repository not found: ${REPO_PATH}`);try{await git(["rev-parse","--is-inside-work-tree"])}catch{throw new Error("The local repository is not a Git repository")}
 const list=await readIndex(REPO_PATH);if(list.some(t=>t?.slug===slug))throw new Error("This slug already exists");const downloads=path.join(REPO_PATH,"downloads"), shotsDir=path.join(REPO_PATH,"assets","screenshots"), dataDir=path.join(REPO_PATH,"data");await fs.mkdir(downloads,{recursive:true});await fs.mkdir(shotsDir,{recursive:true});await fs.mkdir(dataDir,{recursive:true});const zipPath=path.join(downloads,`${slug}.zip`);await fs.writeFile(zipPath,zip.buffer,{flag:"wx"});const screenshotPaths=[];try{for(let i=0;i<shots.length;i++){const ext=extForImage(shots[i].buffer);const dest=path.join(shotsDir,`${slug}-${i+1}${ext}`);await fs.writeFile(dest,shots[i].buffer,{flag:"wx"});screenshotPaths.push(`assets/screenshots/${slug}-${i+1}${ext}`);}}catch(e){await fs.rm(zipPath,{force:true});for(const p of screenshotPaths)await fs.rm(path.join(REPO_PATH,p),{force:true});throw e;}
 const record={slug,name:{de:nameDe,en:nameEn},description:{de:descDe,en:descEn},category,version,tags:safeText(fields.tags,180).split(",").map(x=>x.trim()).filter(Boolean).slice(0,12),download:`downloads/${slug}.zip`,screenshots:screenshotPaths,publishedAt:new Date().toISOString()};const next=[record,...list];await writeAtomic(path.join(dataDir,"tools.json"),JSON.stringify({tools:next},null,2)+"\n");
 try{await git(["add","--",`downloads/${slug}.zip`,"data/tools.json",...screenshotPaths]);await git(["commit","-m",`feat: publish ${slug}`]);await git(["push","origin",BRANCH]);}catch(err){throw new Error(`Files were written locally, but Git push failed: ${err.stderr?.trim()||err.message}`)}return record;}
async function serveStatic(req,res){const url=new URL(req.url,`http://${req.headers.host||"127.0.0.1"}`);let rel=decodeURIComponent(url.pathname);if(rel==="/"||rel==="/admin")rel="/index.html";const file=path.resolve(PUBLIC_DIR,"."+rel);if(!file.startsWith(PUBLIC_DIR+path.sep))return json(res,403,{error:"Forbidden"});try{const stat=await fs.stat(file);if(!stat.isFile())return json(res,404,{error:"Not found"});const type={".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".css":"text/css; charset=utf-8"}[path.extname(file)]||"application/octet-stream";res.writeHead(200,{"Content-Type":type,"Cache-Control":"no-store"});fsSync.createReadStream(file).pipe(res);}catch{json(res,404,{error:"Not found"});}}
async function main(){if(process.argv.includes("--hash-password")){const password=await new Promise(resolve=>{process.stdout.write("Password: ");process.stdin.setEncoding("utf8");process.stdin.once("data",d=>resolve(d.trim()));});const salt=crypto.randomBytes(16);const key=await new Promise((resolve,reject)=>crypto.scrypt(password,salt,64,{N:16384,r:8,p:1},(e,k)=>e?reject(e):resolve(k)));console.log(`scrypt$16384$8$1$${salt.toString("base64")}$${key.toString("base64")}`);return;}
 setInterval(()=>{const now=Date.now();for(const [k,v] of sessions)if(now-v.last>8*60*60*1000)sessions.delete(k);for(const [k,v] of loginAttempts)if(now-v.at>15*60*1000)loginAttempts.delete(k);},60_000).unref();
 const server=http.createServer(async(req,res)=>{setSecurity(res);try{const url=new URL(req.url,`http://${req.headers.host||"127.0.0.1"}`);if(req.method==="POST"&&url.pathname==="/api/login"){const key=clientKey(req),a=loginAttempts.get(key)||{count:0,at:Date.now()};if(a.count>=8 && Date.now()-a.at<10*60*1000)return json(res,429,{error:"Too many attempts. Try again later."});const body=await readJson(req);const stored=ADMIN_HASH.split("$");if(stored.length!==6||stored[0]!=="scrypt")return json(res,500,{error:"Server password configuration is invalid"});const [,N,r,p,saltB64,hashB64]=stored;const derived=await new Promise((resolve,reject)=>crypto.scrypt(String(body.password||""),Buffer.from(saltB64,"base64"),Buffer.from(hashB64,"base64").length,{N:Number(N),r:Number(r),p:Number(p)},(e,k)=>e?reject(e):resolve(k)));if(!timingEqual(derived,Buffer.from(hashB64,"base64"))){loginAttempts.set(key,{count:a.count+1,at:a.at});return json(res,401,{error:"Invalid password"});}loginAttempts.delete(key);const csrf=issueSession(res);return json(res,200,{ok:true,csrf});}
 if(req.method==="GET"&&url.pathname==="/api/session"){const s=requireAuth(req);return json(res,200,s?{authenticated:true,csrf:s.csrf}:{authenticated:false});}
 if(req.method==="POST"&&url.pathname==="/api/logout"){const s=requireAuth(req);if(!s||!requireCsrf(req,s))return json(res,403,{error:"Forbidden"});clearSession(res,req);return json(res,200,{ok:true});}
 if(req.method==="GET"&&url.pathname==="/api/status"){const s=requireAuth(req);if(!s)return json(res,401,{error:"Authentication required"});return json(res,200,await status());}
 if(req.method==="POST"&&url.pathname==="/api/publish"){const s=requireAuth(req);if(!s||!requireCsrf(req,s))return json(res,403,{error:"Forbidden"});const {fields,files}=await collectMultipart(req);const record=await publish(fields,files);return json(res,200,{ok:true,name:record.name?.en||record.slug,slug:record.slug});}
 if(url.pathname.startsWith("/api/"))return json(res,404,{error:"Not found"});return serveStatic(req,res);}catch(e){return json(res,400,{error:String(e.message||e)})}});server.listen(PORT,"127.0.0.1",()=>console.log(`C2V3ZA Tools local admin: http://127.0.0.1:${PORT}`));}
main().catch(err=>{console.error(err);process.exit(1)});
