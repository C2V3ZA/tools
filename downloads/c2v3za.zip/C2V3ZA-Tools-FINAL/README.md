# C2V3ZA Tools — final GitHub Pages package

This package is the finished setup for **C2V3ZA/tools**.

## Folder layout

```text
C2V3ZA-Tools-FINAL/
├── public-site/          ← public website files
├── local-admin/          ← private local publishing app; never upload this folder
├── setup-github.ps1      ← fresh repository setup
├── setup-github.bat      ← Windows shortcut for the setup script
└── start-admin.bat       ← Windows shortcut for the local admin
```

## Fresh installation

1. Install **Git** and **Node.js 20+** on Windows.
2. Extract this ZIP.
3. Double-click `setup-github.bat`.
4. The script clones `https://github.com/C2V3ZA/tools.git` into a sibling folder named `repo` and installs the finished public site there.
5. Review the `repo` folder.
6. Open PowerShell in `repo` and run:

```powershell
git add -A
git commit -m "build: C2V3ZA Tools GitHub Pages"
git push origin main
```

The script intentionally does not push for you automatically.

## GitHub Pages

In the repository on GitHub, open **Settings → Pages** and select **GitHub Actions** as the source. The repository already contains `.github/workflows/pages.yml`.

The expected project-pages URL is:

`https://c2v3za.github.io/tools/`

## Private local admin

The public repository contains no admin page and no GitHub write token.

From the extracted package, double-click `start-admin.bat`, or run:

```powershell
cd .\local-admin
npm install
npm start
```

Open:

`http://127.0.0.1:8787`

The admin password is stored only as a **scrypt password hash** in `local-admin/.env`. The plaintext password is not written to GitHub.

The admin expects the cloned repository in `../repo`, which is the folder created by `setup-github.bat`.

## Git authentication

The admin uses your local Git installation for commits and pushes. Authenticate Git on your own Windows machine with Git Credential Manager or SSH. No GitHub token is embedded in the website or requested by the public page.

## Publishing tools

A tool can contain:

- one ZIP archive, maximum 50 MB
- up to four PNG/JPG/WebP screenshots, maximum 5 MB each
- German and English names
- German and English descriptions
- category
- version
- comma-separated tags

The admin validates the file signatures and metadata before writing files.

Files are stored as:

```text
repo/downloads/<slug>.zip
repo/assets/screenshots/<slug>-1.png
repo/assets/screenshots/<slug>-2.jpg
repo/data/tools.json
```

The public website never extracts or executes tool ZIP files.

## Website features

- dark black grid with red accent styling based on the supplied reference
- responsive desktop and mobile layout
- automatic browser language detection for German/English
- manual DE/EN switch with local browser preference
- search across tool metadata
- screenshot gallery modal
- tool download buttons
- clean empty and error states
- GitHub Pages deployment workflow
- XSS-safe rendering with `textContent`
- restricted public asset paths

The finished package contains only the real C2V3ZA/tools configuration and no demo credentials or fake content.
