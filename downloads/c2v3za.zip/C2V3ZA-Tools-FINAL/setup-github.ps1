$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$repo = Join-Path $root 'repo'
$site = Join-Path $root 'public-site'
Write-Host ''
Write-Host '=====================================' -ForegroundColor DarkGray
Write-Host ' C2V3ZA Tools - GitHub Pages setup' -ForegroundColor Red
Write-Host '=====================================' -ForegroundColor DarkGray
Write-Host ''
if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
  throw 'Git is not installed. Install Git from https://git-scm.com/download/win and run this again.'
}
if (-not (Test-Path (Join-Path $repo '.git'))) {
  if (Test-Path $repo) {
    throw "The folder '$repo' already exists and is not a Git repository. Rename it and run this again."
  }
  Write-Host 'Cloning https://github.com/C2V3ZA/tools.git ...' -ForegroundColor Cyan
  git clone 'https://github.com/C2V3ZA/tools.git' $repo
} else {
  Write-Host 'Existing local clone found: repo' -ForegroundColor Yellow
}
Write-Host ''
Write-Host 'Installing public site files...' -ForegroundColor Cyan
Get-ChildItem -LiteralPath $site -Force | ForEach-Object {
  Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $repo $_.Name) -Recurse -Force
}
Write-Host 'Removing old server-only files...' -ForegroundColor Cyan
foreach ($target in @('server.js','package.json','package-lock.json','scripts','public')) {
  $p = Join-Path $repo $target
  if (Test-Path $p) { Remove-Item -LiteralPath $p -Recurse -Force }
}
Write-Host ''
Write-Host 'Done. The public repository is ready.' -ForegroundColor Green
Write-Host "Local repo: $repo"
Write-Host ''
Write-Host 'Next:' -ForegroundColor White
Write-Host '  1) Open PowerShell in repo'
Write-Host '  2) git add -A'
Write-Host '  3) git commit -m "build: C2V3ZA Tools GitHub Pages"'
Write-Host '  4) git push origin main'
Write-Host ''
Write-Host 'Then start the private admin with start-admin.bat.' -ForegroundColor Yellow
