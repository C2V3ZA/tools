@echo off
setlocal
cd /d "%~dp0local-admin"
if not exist node_modules\ (
  echo Installing local admin dependencies...
  npm install
)
start "C2V3ZA Tools Local Admin" cmd /k "npm start"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:8787"
